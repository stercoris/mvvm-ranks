
let left = 225, xlf = 238;
let tp = 225, xtp = 160;
let i, x;
let fx, fy, deg, schet = 0;
let dvlf = 100, dvtp = 100;
let zomb = document.getElementById("zombie");
let tank = document.getElementById("kvadr");
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
ctx.font = "50px Timens New Roman";
ctx.fillStyle = "black";
ctx.fillText("Счет: " + schet, 10, 50);
window.onkeydown = function move_left(){
    if(event.keyCode==37 || left > 445){//лево
      left=left-10;
      xtp = tp - 25; 
      xlf = left - 50;
        if(left < 0)
        {
          left += 15;
        }
      tank.style.left = left + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.top = xtp + 'px';
      tank.style.transform = ' rotate(270deg)';
      document.getElementById('fire').style.transform = ' rotate(270deg)';

    }
    else if(event.keyCode==39 ){//право
        left=left+10;
        xtp = tp - 5; 
      xlf = left + 60;
        document.getElementById('fire').style.left = xlf + 'px';
        document.getElementById('fire').style.top = xtp + 'px';
        document.getElementById('fire').style.transform = ' rotate(90deg)';

        tank.style.left= left + 'px';
        tank.style.transform = ' rotate(90deg)';
    }
    if(event.keyCode==38){//вверх
      tp -= 10; 
      xtp = tp - 65 ; 
      xlf = left + 15 ;
      tank.style.top = tp + 'px';
      tank.style.transform = ' rotate(0deg)';
      document.getElementById('fire').style.top = xtp + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.transform = ' rotate(0deg)';
    }
    else if(event.keyCode==40){//вниз
      tp += 10;
      tank.style.top= tp + 'px';
      tank.style.transform = ' rotate(180deg)';

      xtp = tp + 40 ; 
      xlf = left - 5;
      document.getElementById('fire').style.top = xtp + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.transform = ' rotate(180deg)';
    }
    if(event.keyCode==32){    
      document.getElementById('fire').style.display = "block";  
      if(xlf > dvlf - 50 && xlf < dvlf + 60)
      {
        if(xtp > dvtp - 80 && xtp < dvtp + 60)
        {
        schet++;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillText("Счет: " + schet, 10, 50);
        dvlf = getRandomInt(500);
        dvtp = getRandomInt(500);
        }
      }
      
    }
};

window.onkeyup = function mt(){
  if(event.keyCode==32){   
    document.getElementById('fire').style.display = "none";     
  }
  
}
setInterval(dvizh, 200);
function dvizh(){
  if(dvlf < left){
    dvlf += 10;
    document.getElementById('zombie').style.left= dvlf + 'px';
    
    
  }
  else{
    dvlf -= 10;
    document.getElementById('zombie').style.left= dvlf + 'px';
  }
  if(dvtp < tp){
    dvtp += 10;
    document.getElementById('zombie').style.top= dvtp + 'px';
  } 
  else{
    dvtp -= 10;
    document.getElementById('zombie').style.top= dvtp + 'px';
  }
}

function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
