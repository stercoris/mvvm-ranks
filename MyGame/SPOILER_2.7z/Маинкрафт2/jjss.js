
let left = 225, xlf = 238;
let tp = 225, xtp = 160;
let i, x;
let fx, fy, deg;
let zomb = document.getElementById("zombie");
window.onkeydown = function move_left(){
    if(event.keyCode==37 || left > 445){//лево
      left=left-10;
      xtp = tp - 25; 
      xlf = left - 50;
        if(left < 0)
        {
          left += 15;
        }
      document.getElementById('kvadr').style.left = left + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.top = xtp + 'px';
      document.getElementById('kvadr').style.transform = ' rotate(270deg)';
      document.getElementById('fire').style.transform = ' rotate(270deg)';

    }
    else if(event.keyCode==39 ){//право
        left=left+10;
        xtp = tp - 5; 
      xlf = left + 60;
        document.getElementById('fire').style.left = xlf + 'px';
        document.getElementById('fire').style.top = xtp + 'px';
        document.getElementById('fire').style.transform = ' rotate(90deg)';

        document.getElementById('kvadr').style.left= left + 'px';
        document.getElementById('kvadr').style.transform = ' rotate(90deg)';
    }
    if(event.keyCode==38){//вверх
      tp -= 10; 
      xtp = tp - 65 ; 
      xlf = left + 15 ;
      document.getElementById('kvadr').style.top = tp + 'px';
      document.getElementById('kvadr').style.transform = ' rotate(0deg)';
      document.getElementById('fire').style.top = xtp + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.transform = ' rotate(0deg)';
    }
    else if(event.keyCode==40){//вниз
      tp += 10;
      document.getElementById('kvadr').style.top= tp + 'px';
      document.getElementById('kvadr').style.transform = ' rotate(180deg)';

      xtp = tp + 40 ; 
      xlf = left - 5;
      document.getElementById('fire').style.top = xtp + 'px';
      document.getElementById('fire').style.left = xlf + 'px';
      document.getElementById('fire').style.transform = ' rotate(180deg)';
    }
    if(event.keyCode==32){
        
      document.getElementById('fire').style.display = "block"; 
      
      if(xlf > 90 && xlf < 150)
      {
        if(xtp >60 && xtp < 120)
        {
        document.getElementById('zombie').style.display = "none";
        }
      }
    }
};

window.onkeyup = function mt(){
  if(event.keyCode==32){
        
    document.getElementById('fire').style.display = "none";     
  }

  
}



// document.getElementById("fire").style.display = "block";
// document.getElementById("fire").style.top = fy + 'px';
// document.getElementById("fire").style.left = left + 20 + 'px';